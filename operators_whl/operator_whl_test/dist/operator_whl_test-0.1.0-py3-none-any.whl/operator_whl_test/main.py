def main():
    print("Hello from operator_whl_test!")
