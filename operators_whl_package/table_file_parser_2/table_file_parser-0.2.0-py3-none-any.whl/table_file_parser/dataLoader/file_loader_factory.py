import os
# 修改相对导入为兼容性导入
try:
    from .hdf5_loader import HDF5Loader
except ImportError:
    from hdf5_loader import HDF5Loader

try:
    from .excel_loader import ExcelLoader
except ImportError:
    from excel_loader import ExcelLoader

try:
    from .single_table_loader import SingleTableLoader
except ImportError:
    from single_table_loader import SingleTableLoader


# 文件读取器工厂
class FileReaderFactory:
    @staticmethod
    def create_reader(input_path, output_prefix, output_format, max_size, chunk_size, write_function):
        ext = os.path.splitext(input_path)[1].lower()
        if ext in ['.csv', '.sav', '.tsv', '.ods', '.parquet','.tab']:
            return SingleTableLoader(input_path, output_prefix, output_format, max_size, chunk_size, write_function)
        elif ext in ['.xls', '.xlsx']:
            return ExcelLoader(input_path, output_prefix, output_format, max_size, chunk_size, write_function)
        elif ext == '.h5':
            return HDF5Loader(input_path, output_prefix, output_format, max_size, chunk_size, write_function)
        else:
            raise ValueError(f"Unsupported file type: {ext}")