import os
try:
    from my_huggingface_descriptive_statistics import get_files_with_suffix
except ImportError:
    from huggingface.my_huggingface_descriptive_statistics import get_files_with_suffix

try:
    from .utils.ole_transform_util import *
except ImportError:
    from utils.ole_transform_util import *

from ReadAndSplit_Chunk import load_config
try:
    from .utils.pdf_marker import process_single_pdf
except ImportError:
    from utils.pdf_marker import process_single_pdf

try:
    from .utils.sciencedb_textfile_output_info_generator import Process_Textfile_Output_Info
except ImportError:
    from utils.sciencedb_textfile_output_info_generator import Process_Textfile_Output_Info

try:
    from .utils.FileLogger import FileErrorLogger, Timer
except ImportError:
    from utils.FileLogger import FileErrorLogger, Timer

from datetime import datetime


def process_text_file(text_path, output_root):
    print(f"Processing {text_path}")
    ext = os.path.splitext(text_path)[1].lower()
    file_name_sub = text_path.split(os.sep)[-1]
    file_name_sub = file_name_sub.split('.')[0]

    logger = FileErrorLogger()
    file_log_dir = logger.get_file_log_dir()
    with Timer() as timer:
        # 初始化输出信息
        output_info = Process_Textfile_Output_Info(output_format="markdown")
        output_info.processing_start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        output_info.file_id = file_name_sub
        # markdown_list = []
        # meta_json_list = []
        image_list = []

        try :
            process_single_pdf(text_path, output_root)
            markdown_output_dir = os.path.join(output_root, f"{file_name_sub}.md")
            # 如果存在pdf，则说明pdf转换成功
            if os.path.exists(markdown_output_dir):
                output_info.is_markdown_proceed = True
                # markdown_list.append(markdown_output_dir)
                output_info.markdown_file_path = markdown_output_dir
            else:
                output_info.is_markdown_proceed = False
                output_info.markdown_file_path = []

            #如果存在meta.json，则说明meta转换成功
            meta_json_dir = os.path.join(output_root, f"{file_name_sub}_meta.json")
            if os.path.exists(meta_json_dir):
                output_info.is_json_proceed = True
                # meta_json_list.append(meta_json_dir)
                output_info.json_file_path = meta_json_dir
            else:
                output_info.is_json_proceed = False
                output_info.json_file_path = []

            # 获取output_root下所有图片的路径,如果为空则不加入列表
            jpeg_image_list = get_files_with_suffix(output_root, "jpeg")
            if jpeg_image_list is not None and jpeg_image_list != [] and len(jpeg_image_list) > 0:
                image_list.extend(jpeg_image_list)
            png_image_list = get_files_with_suffix(output_root, "png")
            if png_image_list is not None and png_image_list != [] and len(png_image_list) > 0:
                image_list.extend(png_image_list)
            # 如果图片列表不为空，则说明图片转换成功
            if len(image_list) > 0:
                output_info.is_image_proceed = True
                output_info.image_file_path = image_list
            else:
                output_info.is_image_proceed = False
                output_info.image_file_path = []

        except Exception as e:
            logger.output_log(str(e), file_name_sub)
            print(f"Error processing {text_path}: {str(e)}")
            # 如果有一个没成功，则说明有错误日志生成
            log_file_path = file_log_dir + os.sep + file_name_sub + "_error.log"
            output_info.log_file_path = os.path.abspath(log_file_path)
            output_info.is_markdown_proceed = False
            output_info.markdown_file_path = None
        finally:
            # 进行输出结果组装
            # 记录处理结束时间
            output_info.processing_end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            final_file_processing_result = output_info.generate_output_info()
            print(final_file_processing_result)
            return final_file_processing_result

if __name__ == "__main__":
    index = 0
    index_min = 0
    index_max = 0

    # 使用配置
    config = load_config()
    output_root = config.get('paths', {}).get('output_root', f'{os.sep}default{os.sep}data')
    data_root = config.get('paths', {}).get('text_data_root', f'{os.sep}default{os.sep}data')

    form_type_list = [".pdf", ".docx", ".doc", ".ppt", ".pptx"]
    form_folder_list = ["pdf", "docx", "doc", "ppt", "pptx"]

    for i in range(index_min, index_max + 1):
        index = i
        output_root += form_folder_list[index] + os.sep

        # data_root = data_root + form_folder_list[index]

        file_name_list = os.listdir(data_root)
        absolute_paths = [os.path.join(data_root, fname) for fname in file_name_list]
        if absolute_paths is None or len(absolute_paths) == 0:
            print(f"输入目录 {data_root} 中没有文件！")

        for file_name in absolute_paths:
            # 跳过临时文件和非PPTX文件
            file_name_sub = file_name.split(os.sep)[-1]
            if file_name_sub.startswith('~$'):
                continue
            process_text_file(file_name, output_root + file_name_sub.split('.')[0])


        data_root = config.get('paths', {}).get('text_data_root', f'{os.sep}default{os.sep}data')
        output_root = config.get('paths', {}).get('output_root', f'{os.sep}default{os.sep}data')
