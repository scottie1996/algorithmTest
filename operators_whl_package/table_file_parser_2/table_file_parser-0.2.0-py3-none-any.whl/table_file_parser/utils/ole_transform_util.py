import io
import re
import tempfile

from PIL import Image
import subprocess
import os

def process_ole_object(ole_shape, slide_num, image_dir, markdown_content):
    """处理OLE对象（非占位符类型）"""
    try:
        # 尝试提取OLE对象为图片
        ole_image = extract_ole_image(ole_shape)
        if ole_image:
            temp_img_path = f"{tempfile.gettempdir()}/ole_temp_{slide_num}.png"
            ole_image.save(temp_img_path, "PNG")

            # 使用pix2tex识别公式
            latex_code = recognize_formula(temp_img_path)

            if latex_code:
                # 保存OLE对象图片
                img_filename = f"slide_{slide_num}_ole_{ole_shape.name}.png"
                img_path = os.path.join(image_dir, img_filename)
                ole_image.save(img_path, "PNG")

                markdown_content.append(f"![公式]({img_path})\n\n")
                markdown_content.append(f"$${latex_code}$$\n\n")
            else:
                markdown_content.append(f"![OLE对象]({temp_img_path})\n\n")
                markdown_content.append("**[未识别的OLE对象]** 需手动处理\n\n")
        else:
            markdown_content.append(f"**[无法转换的OLE对象: {ole_shape.name}]** 需手动处理\n\n")
    except Exception as e:
        markdown_content.append(f"**[OLE处理错误: {ole_shape.name} - 错误: {str(e)}]** 需手动处理\n\n")


def process_special_formats(text):
    """处理特殊格式，如公式、列表等"""
    # 检测数学公式模式
    if re.search(r'[A-Za-z]̂\s*=\s*[\d,.]+\s*[+-/*]\s*[\d,.]*[A-Za-z]', text):
        return f"$${convert_to_latex(text)}$$\n\n"

    # 检测列表模式
    if re.match(r'^\s*[•●∙*+-]+\s+', text) or re.match(r'^\s*\d+\.\s+', text):
        return convert_to_markdown_list(text)

    return text


def convert_to_latex(text):
    """简单的文本到LaTeX转换"""
    text = text.replace('̂', '\\hat')
    text = text.replace(',', '.')  # 欧洲数字格式
    return text


def convert_to_markdown_list(text):
    """将文本转换为Markdown列表"""
    lines = text.strip().split('\n')
    markdown_lines = []

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # 处理无序列表
        if re.match(r'^[•●∙*+-]', line):
            line = re.sub(r'^[•●∙*+-]', '-', line)
        # 处理有序列表
        elif re.match(r'^\d+\.', line):
            line = re.sub(r'^\d+\.', '1.', line)

        markdown_lines.append(line)

    return '\n'.join(markdown_lines)


def is_placeholder(shape):
    """检查形状是否为占位符"""
    try:
        return hasattr(shape, 'placeholder_format')
    except:
        return False


def save_image(shape, slide_num, image_dir, markdown_content):
    """保存普通图片并添加到Markdown内容"""
    image = shape.image
    img_filename = f"slide_{slide_num}_img_{image.filename}"
    img_path = os.path.join(image_dir, img_filename)

    with open(img_path, 'wb') as f:
        f.write(image.blob)

    markdown_content.append(f"![图片]({img_path})\n\n")


def extract_ole_image(ole_shape):
    """尝试从OLE对象提取图像"""
    try:
        if hasattr(ole_shape, 'blob'):
            ole_data = ole_shape.blob
            try:
                img = Image.open(io.BytesIO(ole_data))
                return img
            except:
                return None
        return None
    except:
        return None


def recognize_formula(image_path):
    """使用多种方法识别公式"""
    # 优先使用pix2tex
    try:
        result = subprocess.run(
            ["pix2tex", image_path],
            capture_output=True,
            text=True
        )
        return result.stdout.strip()
    except:
        pass

    # 备选：使用tesseract OCR
    try:
        temp_path = f"{tempfile.gettempdir()}/formula_temp.png"
        with Image.open(image_path) as img:
            img = img.convert('L')
            img.save(temp_path)

        result = subprocess.run(
            ["tesseract", temp_path, "stdout", "--oem", "1", "--psm", "7"],
            capture_output=True,
            text=True
        )
        ocr_text = result.stdout.strip()

        if '=' in ocr_text:
            return convert_text_formula_to_latex(ocr_text)
    except:
        pass

    return None


def convert_text_formula_to_latex(text):
    """将文本公式转换为LaTeX格式"""
    text = text.replace('̂', '\\hat')
    text = text.replace(',', '.')  # 欧洲数字格式
    return text