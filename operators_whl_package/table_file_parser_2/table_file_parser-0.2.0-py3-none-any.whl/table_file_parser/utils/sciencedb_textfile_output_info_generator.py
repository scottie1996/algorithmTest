class Process_Textfile_Output_Info:
    def __init__(self, output_format="markdown"):
        self.file_id = None
        self.results = {}
        self.is_markdown_proceed = False
        self.is_json_proceed = False
        self.is_image_proceed = False
        self.markdown_file_path = None
        self.json_file_path = None
        self.image_file_path = None
        self.log_file_path = None
        self.processing_start_time = None
        self.processing_end_time = None
        self.output_format = output_format

    def generate_output_info(self):

        self.results = {
            f"{self.output_format}": self.is_markdown_proceed,
            "meta_json": self.is_json_proceed,
            "images": self.is_image_proceed,
        }

        final_file_processing_result = {
            "file_id": self.file_id,
            "results": self.results,
            f"{self.output_format}Files": self.markdown_file_path,
            "metaJsonFile": self.json_file_path,
            "imageFile": self.image_file_path,
            "logFile": self.log_file_path,
            "start_time": self.processing_start_time,
            "end_time": self.processing_end_time
        }
        return final_file_processing_result

class FileProcessingStrategy:
    def process(self, file_path):
        raise NotImplementedError
