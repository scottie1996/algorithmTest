import os

from marker.converters.pdf import PdfConverter
from marker.converters.table import TableConverter
from marker.converters.ocr import OCRConverter
from marker.models import create_model_dict
from marker.config.parser import ConfigParser
from marker.output import save_output

# api_key = os.getenv("DASHSCOPE_API_KEY")
def process_single_pdf(input_path, output_dir):
    try:
        config = {
            "output_format": "markdown",  # 控制输出类型，可选值为："json"、"html"、"markdown"，默认是 "markdown"
            # "ADDITIONAL_KEY": "VALUE",
            "format_lines": True,  # 等价于命令行 --format_lines，开启后会尝试对段落进行多行合并为一段，利于语义理解
            "force_ocr": True,  # 等价于 --force_ocr，强制对所有页面使用 OCR，即使页面中已有可提取的文字（如扫描件、图片）
            "use_llm": False,  # 等价于 --use_llm，开启后会使用 LLM 对提取的文本进行处理

            # "llm_service": "marker.services.openai.OpenAIService",
            # "openai_api_key": api_key,
            # "openai_base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",  # 假设为阿里云百炼平台
            # "openai_model": "qwen-plus-latest",
        }
        config_parser = ConfigParser(config)

        converter = PdfConverter(
            config=config_parser.generate_config_dict(),
            artifact_dict=create_model_dict(),
            processor_list=config_parser.get_processors(),
            renderer=config_parser.get_renderer(),
            # llm_service=config_parser.get_llm_service()
        )

        rendered = converter(input_path)

        output_dir = output_dir
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        fname_base = input_path.split(os.sep)[-1].split('.')[0]  # 文件标识名(一般为.pdf前面的名字，不包括父路径)
        save_output(rendered, output_dir, fname_base)
    except Exception as e:
        print(f"Error processing {input_path}: {e}")


def process_single_table(input_path, output_dir):
    try:
        config = {
            "output_format": "markdown",  # 控制输出类型，可选值为："json"、"html"、"markdown"，默认是 "markdown"
            "ADDITIONAL_KEY": "VALUE",
            "format_lines": True,  # 等价于命令行 --format_lines，开启后会尝试对段落进行多行合并为一段，利于语义理解
            "force_ocr": True,  # 等价于 --force_ocr，强制对所有页面使用 OCR，即使页面中已有可提取的文字（如扫描件、图片）
            "use_llm": False,  # 等价于 --use_llm，开启后会使用 LLM 对提取的文本进行处理

            "llm_service": "marker.services.openai.OpenAIService",
            # "openai_api_key": api_key,
            "openai_base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",  # 假设为阿里云百炼平台
            "openai_model": "qwen-plus-latest",
        }
        config_parser = ConfigParser(config)

        converter = TableConverter(
            config=config_parser.generate_config_dict(),
            artifact_dict=create_model_dict(),
            processor_list=config_parser.get_processors(),
            renderer=config_parser.get_renderer(),
            llm_service=config_parser.get_llm_service()
        )

        rendered = converter(input_path)

        output_dir = output_dir
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        fname_base = input_path.split(os.sep)[-1].split('.')[0]  # 文件标识名(一般为.pdf前面的名字，不包括父路径)
        save_output(rendered, output_dir, fname_base)
    except Exception as e:
        print(f"Error processing {input_path}: {e}")

def process_single_ocr(input_path, output_dir):
    try:
        config = {
            "output_format": "markdown",  # 控制输出类型，可选值为："json"、"html"、"markdown"，默认是 "markdown"
            "ADDITIONAL_KEY": "VALUE",
            #"format_lines": True,  # 等价于命令行 --format_lines，开启后会尝试对段落进行多行合并为一段，利于语义理解
            "force_ocr": True,  # 等价于 --force_ocr，强制对所有页面使用 OCR，即使页面中已有可提取的文字（如扫描件、图片）
            #"use_llm": False,  # 等价于 --use_llm，开启后会使用 LLM 对提取的文本进行处理

            # "llm_service": "marker.services.openai.OpenAIService",
            # "openai_api_key": api_key,
            # "openai_base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",  # 假设为阿里云百炼平台
            # "openai_model": "qwen-plus-latest",
        }
        config_parser = ConfigParser(config)

        converter = OCRConverter(
            config=config_parser.generate_config_dict(),
            artifact_dict=create_model_dict(),
            processor_list=config_parser.get_processors(),
            renderer=config_parser.get_renderer()
            # llm_service=config_parser.get_llm_service()
        )

        rendered = converter(input_path)

        output_dir = output_dir
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        fname_base = input_path.split(os.sep)[-1].split('.')[0]  # 文件标识名(一般为.pdf前面的名字，不包括父路径)
        save_output(rendered, output_dir, fname_base)
    except Exception as e:
        print(f"Error processing {input_path}: {e}")

def process_single_pptx(input_path, output_dir):
    try:
        config = {
            "output_format": "markdown",  # 控制输出类型，可选值为："json"、"html"、"markdown"，默认是 "markdown"
            "ADDITIONAL_KEY": "VALUE",
            "format_lines": True,  # 等价于命令行 --format_lines，开启后会尝试对段落进行多行合并为一段，利于语义理解
            "force_ocr": True,  # 等价于 --force_ocr，强制对所有页面使用 OCR，即使页面中已有可提取的文字（如扫描件、图片）
            "use_llm": False,  # 等价于 --use_llm，开启后会使用 LLM 对提取的文本进行处理

            "llm_service": "marker.services.openai.OpenAIService",
            # "openai_api_key": api_key,
            "openai_base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",  # 假设为阿里云百炼平台
            "openai_model": "qwen-plus-latest",
        }
        config_parser = ConfigParser(config)

        converter = PdfConverter(
            config=config_parser.generate_config_dict(),
            artifact_dict=create_model_dict(),
            processor_list=config_parser.get_processors(),
            renderer=config_parser.get_renderer(),
            llm_service=config_parser.get_llm_service()
        )

        rendered = converter(input_path)

        output_dir = output_dir
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        fname_base = input_path.split(os.sep)[-1].split('.')[0]  # 文件标识名(一般为.pdf前面的名字，不包括父路径)
        save_output(rendered, output_dir, fname_base)
    except Exception as e:
        print(f"Error processing {input_path}: {e}")


if __name__ == "__main__":
    index = 0
    index_min = 0
    index_max = 0
    form_folder_list = ["pdf", "docx", "pptx"]

    base_input_path = "D:\\hqr\\workspace\\csvfiles\\text_files\\"
    base_output_dir = "D:\\hqr\\workspace\\csvfiles\\output\\"

    for i in range(index_min, index_max + 1):
        index = i
        # if not is_testing_generate:
        output_dir = base_output_dir + form_folder_list[index] + os.sep

        data_root = base_input_path + form_folder_list[index] + os.sep

        file_list = os.listdir(data_root)
        for file_name in file_list:
            process_single_pdf(data_root + file_name, output_dir + file_name.split('.')[0])


